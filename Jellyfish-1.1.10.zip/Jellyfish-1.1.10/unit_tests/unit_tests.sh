#! /bin/sh

cd tests
. ./compat.sh

${DIR}/test_all
